<div class="navbar navbar-inverse navbar-fixed-top" id="categorias">
   <div class="navbar-inner">
      <div class="container">
         <button type="button" class="btn btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         </button>
         <a class="brand" id="logoNombre" href="#">LTDLE</a>
         <!--<span id="titCategorias">Categor&iacute;as</span>-->
         <div class="nav-collapse collapse" style="height: 0px;">
            <ul class="nav">
               <li class=""><a href="index.php?pag=abrt">Abarrotes</a></li>
               <li class=""><a href="index.php?pag=beb">Bebidas</a></li>
               <li class=""><a href="index.php?pag=cuiPer">Cuidado personal</a></li>
               <li class=""><a href="index.php?pag=desy">Desayuno</a></li>
               <li class=""><a href="index.php?pag=embt">Embutidos</a></li>
               <li class=""><a href="index.php?pag=eltds">Enlatados</a></li>
               <li class=""><a href="index.php?pag=glltgsn">Galletas y Golosinas</a></li>
               <li class=""><a href="index.php?pag=licrs">Licores</a></li>
               <li class=""><a href="index.php?pag=lmpz">Limpieza</a></li>
               <li class=""><a href="index.php?pag=snkspqs">Snacks y Piqueos</a></li>
			   
            </ul>
         </div>
      </div>
   </div>
</div>
<!--VERSION 2
   <div class="navbar navbar-inverse navbar-fixed-top" id="categorias">
     <div class="navbar-inner">
   	<div class="container">
   	  <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
   		<span class="icon-bar"></span>
   		<span class="icon-bar"></span>
   		<span class="icon-bar"></span>
   	  </button>
   	  <a class="brand pull-left" id="logoNombre" href="#">VONS</a>
   	  <span class="brand" id="titCategorias">Categor&iacute;as</span>
   	  <div class="nav-collapse in collapse" style="height: auto;">
   		<ul class="nav" id="listaCategorias">
   		  <li class=""><a href="#">Abarrotes</a></li>
   		  <li class=""><a href="#">Bebidas</a></li>
   		  <li class=""><a href="#">Cuidado personal</a></li>
   		  <li class=""><a href="#">Desayuno</a></li>
   		  <li class=""><a href="#">Embutidos</a></li>
   		  <li class=""><a href="#">Enlatados</a></li>
   		  <li class=""><a href="#">Galletas</a></li>
   		  <li class=""><a href="#">Licores</a></li>
   		  <li class=""><a href="#">Licores</a></li>
   		  <li class=""><a href="#">Limpieza</a></li>
   		  <li class=""><a href="#">Snacks y Piqueos</a></li>
   		</ul>
   	  </div>
   	  
   	</div>
     </div>
   </div>
   -->
<!--VERSION 1
   <ul class="nav nav-tabs">
   	<li><a href="#">Abarrotes</a></li>
   	<li><a href="#">Bebidas</a></li>
   	<li><a href="#">Cuidado Personal</a></li>
   	<li><a href="#">Desayuno</a></li>
   	<li><a href="#">Embutidos</a></li>
   	<li><a href="#">Enlatados</a></li>
   	<li><a href="#">Galletas y golosinas</a></li>
   	<li><a href="#">Licores</a></li>
   	<li><a href="#">Limpieza</a></li>
   	<li><a href="#">Snacks y Piqueos</a></li>
   </ul>-->