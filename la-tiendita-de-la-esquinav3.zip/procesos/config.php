<?php 
$config = array();
$config['servidor']='mysql.nixiweb.com';
$config['base_datos']='u572712140_ltdle';
$config['usuario']='u572712140_root';
$config['password']='adminadmin';

?>