<h1 class="title-pags">Contacto</h1>
<p class="text-justified espaciar-texto">Las sugerencias o inconveniente pueden ser enviadas a trav&eacute;s del siguiente formulario, donde  gustosos los atenderemos.</p>
<div class='widget ContactForm' id='ContactForm1'>
	<div class='contact-form-widget'>
		<div class='form'>
			<form action="" name='contact-form' method="">
				<p class="labelFormularioContacto">Nombre<span class="alertaForm">(*)</span><p>
				<input class='contact-form-name' id='ContactForm1_contact-form-name' name='name' size='30' type='text' value=''/>
				<p class="labelFormularioContacto">Correo electr&oacute;nico <span class="alertaForm">(*)</span></p>
				<input class='contact-form-email' id='ContactForm1_contact-form-email' name='email' size='30' type='text' value=''/>
				<p class="labelFormularioContacto">Mensaje <span class="alertaForm">(*)</span></p>
				<textarea class='contact-form-email-message' cols='25' id='ContactForm1_contact-form-email-message' name='email-message' rows='5'></textarea>
				<input class='contact-form-button contact-form-button-submit' id='ContactForm1_contact-form-submit' type='button' value='Enviar'/>
		  </form>
		</div>
	</div>
</div>
