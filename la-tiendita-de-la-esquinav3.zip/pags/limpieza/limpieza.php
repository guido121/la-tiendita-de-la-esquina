<div id="ayuda">
	<h1>Limpieza</h1>
</div>