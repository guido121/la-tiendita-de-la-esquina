<div>
	<div id="mas_vendidos_abarrotes">
		<h2>Lo mas vendido</h2>
		<div id="img1" class="img_abarrotes"></div>
		<div id="img2" class="img_abarrotes"></div>
	</div>
	<div id="abarrotes_ofertas">
		<h2>Ofertas</h2>
		<div id="img3" class="img_abarrotes"></div>
		<div id="img4" class="img_abarrotes"></div>
	</div>
</div>