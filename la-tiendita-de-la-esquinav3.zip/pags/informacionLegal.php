<div>
	<h1 class="title-pags">T&eacute;rminos y condiciones</h1>
	<p class="text-justified espaciar-texto">Este contrato describe los t&eacute;rminos y condiciones generales aplicables al uso de los servicios 
	ofrecidos por www.latienditadelaesquina.com.pe. Cualquier persona que desee acceder y/o
	usar el sitio o los servicios podr&aacute; hacerlo sujet&aacute;ndose a los T&eacute;rminos y Condiciones Generales, junto
	con todas las dem&aacute;s pol&iacute;ticas y principios que rigen y que son incorporados al presente
	por referencia. 
	El Usuario debe leer, entender y aceptar todas las condiciones establecidas en los T&eacute;rminos y Condiciones
	Generales y en las Pol&iacute;ticas de Privacidad as&iacute; como en los dem&aacute;s documentos incorporados a los mismos por
	referencia, previo a su inscripci&oacute;n como Usuario de latienditadelaesquina.com.pe .</p>
<p class="text-justified espaciar-texto">A trav&eacute;s del Sitio Web ofrecemos a los Usuarios la posibilidad de realizar pedidos online de productos comestibles
 a domicilio y para llevar, as&iacute; como permitir la prestaci&oacute;n de distintos servicios a trave&eacute;s del Portal (Servicios posteriores).</p>
</div>
