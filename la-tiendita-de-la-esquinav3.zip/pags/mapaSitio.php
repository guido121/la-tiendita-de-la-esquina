
<div id="mapa-nav" >
<div class="mapa-nav-cont">
	<h1 class="title-pags">Mapa de sitio</h1>
	<div>
	<h2>Productos</h2>
	<ul>
		<li class=""><a href="index.php?pag=abrt">Abarrotes</a></li>
		<li class=""><a href="index.php?pag=beb">Bebidas</a></li>
		<li class=""><a href="index.php?pag=cuiPer">Cuidado personal</a></li>
		<li class=""><a href="index.php?pag=desy">Desayuno</a></li>
		<li class=""><a href="index.php?pag=embt">Embutidos</a></li>
		<li class=""><a href="index.php?pag=eltds">Enlatados</a></li>
		<li class=""><a href="index.php?pag=glltgsn">Galletas y Golosinas</a></li>
		<li class=""><a href="index.php?pag=licrs">Licores</a></li>
		<li class=""><a href="index.php?pag=lmpz">Limpieza</a></li>
		<li class=""><a href="index.php?pag=snkspqs">Snacks y Piqueos</a></li>
	</ul>
	</div>
	<div class="mapa-nav-cont">
		<h2>Ayuda</h2>
		
	<ul>
		<li><a href="#" >Beneficios</a></li>
		<li><a href="#" >Comprar</a></li>
		<li><a href="#" >Formas de Pago</a></li>
		<li><a href="#" >Registro</a></li>
		<li><a href="#" >Preguntas Frecuentas</a></li>
	</ul>
	</div>
</div>
</div>
