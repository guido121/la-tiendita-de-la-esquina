<div>
	
	<h1 class="title-pags">Nosotros</h1>
	
	<div class="elementosNosotros">
	<h2 class="sub-title">&iquest;Qu&eacute; es la Tiendita de la Esquina?</h2>
	<p class="text-justified espaciar-texto">
		Actualmente, el n&uacute;mero de supermercados o mega centros comerciales ha aumentado dr&aacute;sticamente, esto ha
		generado un exagerado movimiento de dinero en dicho sector y por consiguiente ha aumentado el n&uacute;mero de opciones de
		compra para los usuarios sin cuidar su bolsillo. Sin embargo, debido a que pocos son los centros que publican
		adecuadamente los precios de sus productos v&iacute;a internet, nace esta idea, la cual b&aacute;sicamente es generar una base de
		datos online de precios en donde el usuario pueda compararlos entre s&iacute; de acuerdo al producto deseado.
	</p>
	</div>
	<img id="tiendaEsquina" src="img/tienda.jpg" alt="tienda de la esquina"/>
	
	
	<div class="clear"></div>
	<h2 class="sub-title">Misi&oacute;n</h2>
	<div> 
	<p class="text-justified espaciar-texto">
		Facilitar una gran variedad de productos alimenticios al precio m&aacute;s bajo del mercado con el respaldo de nuestros proveedores estrat&eacute;gicos.
	</p>
	</div>
	<div class="clear"></div>
	<h2 class="sub-title">Visi&oacute;n</h2>
	<div > 	
	<p class="text-justified espaciar-texto">
		Ser una de las empresas  E-Comerce n&uacute;mero uno con mayor actividad y demanda en el mercado mundial. Y a la vez una de las m&aacute;s reconocidas por ofrecer productos de calidad a los m&aacute;s bajos precios.
	</p>
	</div>
</div>
