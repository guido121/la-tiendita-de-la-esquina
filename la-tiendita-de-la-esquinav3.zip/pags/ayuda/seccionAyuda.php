<div id="ayuda">
	
	<div id="cAyuda">
	<h2>Centro de ayuda</h2>
		<div class="bloqueAyuda">
			<ul id="enla">
				<li><a href="#" >Beneficios</a></li>
				<li><a href="#" >Comprar</a></li>
				<li><a href="#" >Formas de Pago</a></li>
				<li><a href="#" >Registro</a></li>
				<li><a href="#" >Preguntas Frecuentas</a></li>
			</ul>
		</div>
		<div class="bloqueAyuda preguntaRespuesta">
			<ul>
				<li><a href="#">Pregunta 1</a></li>
				<li><a href="#">Pregunta 2</a></li>
				<li><a href="#">Pregunta 3</a></li>
				<li><a href="#">Pregunta 4</a></li>
			</ul>
		</div>
		<div class="bloqueAyuda preguntaRespuesta">
			<p>Usted debe...</p>
		</div>	
    </div>
	<div class="clear"></div>
	<div class="label-input" id="contenedor-botones-ayuda">
		<input class="btn btn-info" type="submit" value="Volver"/> 
		<input class="btn btn-info" type="submit" value="Contactarse con la empresa"/>
		<input class="btn btn-info" type="submit" value="Seguir comprando"/>
	</div>
</div>